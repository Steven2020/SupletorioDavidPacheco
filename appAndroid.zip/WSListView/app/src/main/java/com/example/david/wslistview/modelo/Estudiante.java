package com.example.david.wslistview.modelo;

public class Estudiante {
    private Integer cedula;
    private String nombres;
    private String apellidos;
    private double arquitectura;
    private double programacion;
    private double etica;
    private double estadistica;
    private String contabilidad;

    public Integer getCedula() {
        return cedula;
    }

    public void setCedula(Integer cedula) {
        this.cedula = cedula;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public double getArquitectura() {
        return arquitectura;
    }

    public void setArquitectura(double arquitectura) {
        this.arquitectura = arquitectura;
    }

    public double getProgramacion() {
        return programacion;
    }

    public void setProgramacion(double programacion) {
        this.programacion = programacion;
    }

    public double getEtica() {
        return etica;
    }

    public void setEtica(double etica) {
        this.etica = etica;
    }

    public double getEstadistica() {
        return estadistica;
    }

    public void setEstadistica(double estadistica) {
        this.estadistica = estadistica;
    }

    public String getContabilidad() {
        return contabilidad;
    }

    public void setContabilidad(String contabilidad) {
        this.contabilidad = contabilidad;
    }
}
