package com.example.david.wslistview.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.david.wslistview.R;
import com.example.david.wslistview.modelo.Estudiante;

import java.util.ArrayList;

public class AdapterAlumno extends BaseAdapter {
    private Context context;
    private ArrayList<Estudiante> listaAlumno;

    public AdapterAlumno(Context context, ArrayList<Estudiante> listaAlumno) {
        this.context = context;
        this.listaAlumno = listaAlumno;
        Log.e("++++++++++++++++", "alumnos:" + listaAlumno.size());
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public ArrayList<Estudiante> getListaAlumno() {
        return listaAlumno;
    }

    public void setListaAlumno(ArrayList<Estudiante> listaAlumno) {
        this.listaAlumno = listaAlumno;
    }

    @Override
    public int getCount() {
        return listaAlumno.size();
    }

    @Override
    public Object getItem(int position) {
        return listaAlumno.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = View.inflate(context,R.layout.display_alumno, null);
        TextView txtcedula = (TextView) convertView.findViewById(R.id.lbl_cedula);
        TextView txtNombres = (TextView) convertView.findViewById(R.id.lbl_Nombres);
        TextView txtapellidos = (TextView) convertView.findViewById(R.id.lbl_apellidos);
        TextView txtarquitectura = (TextView) convertView.findViewById(R.id.arquitectura);
        TextView txtprogramacion = (TextView) convertView.findViewById(R.id.programacion);
        TextView txtetica = (TextView) convertView.findViewById(R.id.etica);
        TextView txtestadictica = (TextView) convertView.findViewById(R.id.estadictica);
        TextView txtcontabilidad = (TextView) convertView.findViewById(R.id.contabilidad);
        Estudiante estudiante = listaAlumno.get(position);

        txtcedula.setText(String.valueOf("cedula Estudiante: "+estudiante.getCedula()));
        txtNombres.setText("nombres: " + estudiante.getNombres());
        txtapellidos.setText("Apellidos: " + estudiante.getApellidos());
        txtarquitectura.setText("Nota Arquitectura: " + String.valueOf(estudiante.getArquitectura()));
        txtprogramacion.setText(String.valueOf("Nota Programacion" + estudiante.getProgramacion()));
        txtetica.setText(String.valueOf("Nota Etica" + estudiante.getEtica()));
        txtestadictica.setText(String.valueOf("Nota Estadistica" + estudiante.getEstadistica()));
        txtcontabilidad.setText(String.valueOf("Nota Contabilidad" + estudiante.getContabilidad()));

        return convertView;

    }
}
