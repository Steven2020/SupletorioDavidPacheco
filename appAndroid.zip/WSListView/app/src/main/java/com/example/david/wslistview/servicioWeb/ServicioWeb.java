package com.example.david.wslistview.servicioWeb;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ServicioWeb extends AsyncTask< String,Void,String > {

    public String cadenadevolver = "ERROR AL PRESENTAR";

    public ServicioWeb(){

    }



    @Override
    protected String doInBackground(String... params) {
        String cadena = params[0];
        URL url = null;

        String devuelve = "No devuelve nada";
        StringBuilder stringBuilder = new StringBuilder();
        if (params[1] == "1") {
            try {
                url = new URL(cadena);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                int codigoRespuesta = conexion.getResponseCode();
                Log.e("++++++++++++++++", "alumnos:" + codigoRespuesta);
                if (codigoRespuesta == HttpURLConnection.HTTP_OK) {
                    InputStream in = new BufferedInputStream(conexion.getInputStream());
                    BufferedReader lector = new BufferedReader(new InputStreamReader(in));
                    devuelve = lector.readLine();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return devuelve;
        }
        if (params[1] == "2") {
            try {
                url = new URL(cadena);
                HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
                Log.e("++++++++++++++++", "alumnos:" + conexion);
                int codigoRespuesta = conexion.getResponseCode();
                Log.e("++++++++++++++++", "alumnos:" + codigoRespuesta);
                if (codigoRespuesta == HttpURLConnection.HTTP_OK) {
                    InputStream in = new BufferedInputStream(conexion.getInputStream());
                    BufferedReader lector = new BufferedReader(new InputStreamReader(in));
                    devuelve = lector.readLine();
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return devuelve;
        }


        return devuelve;
    }

    @Override
    protected void onPostExecute(String s) {
        cadenadevolver = s;
    }
}
