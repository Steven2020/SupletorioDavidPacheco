package com.example.david.wslistview.Interfacez;

import com.example.david.wslistview.fragmento.frg_buscarID;

public interface IFragments extends frg_buscarID.OnFragmentInteractionListener {
}



