package com.example.david.wslistview.fragmento;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.david.wslistview.R;
import com.example.david.wslistview.adapter.AdapterAlumno;
import com.example.david.wslistview.modelo.Alumno;
import com.example.david.wslistview.modelo.Estudiante;
import com.example.david.wslistview.servicioWeb.ServicioWeb;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link frg_buscarID.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link frg_buscarID#newInstance} factory method to
 * create an instance of this fragment.
 */
public class frg_buscarID extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private Context globalContext = null;

    private OnFragmentInteractionListener mListener;
    String consultarID = "http://10.20.59.146:8080/DavidPacheco/ServicioRest/estudiante/estudianteId?cedula=";
    EditText id;
    Button buscarID;
    ServicioWeb servicio;
    List<Estudiante> listaestudiantes;
    ListView listaBUscada;
    AdapterAlumno alumnoAdapter;

    public frg_buscarID() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment frg_buscarID.
     */
    // TODO: Rename and change types and number of parameters
    public static frg_buscarID newInstance(String param1, String param2) {
        frg_buscarID fragment = new frg_buscarID();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View vista = inflater.inflate(R.layout.fragment_frg_buscar_id, container, false);
        id = vista.findViewById(R.id.txtID);
        buscarID = vista.findViewById(R.id.btnBuscarID);
        listaBUscada = vista.findViewById(R.id.listViewAlum);
        globalContext = this.getActivity();
        buscarID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listaestudiantes = new ArrayList<Estudiante>();
                servicio = new ServicioWeb();
                String cadenaLlamada = consultarID + id.getText().toString();
                servicio.execute(cadenaLlamada,"2");
                try {
                    String cadena = servicio.get();
                    Log.e("++++++++++++++++", "alumnos:" + cadena);
                    JSONObject jsonArray = new JSONObject(cadena);
                    //JSONObject respuestaJson = new JSONObject(cadena);
                    //for(int i = 0; i < jsonArray.length(); i++){
                        Estudiante estudianteNodo = new Estudiante();
                        estudianteNodo.setCedula(Integer.parseInt(jsonArray.getString("cedula")));
                        estudianteNodo.setNombres(jsonArray.getString("nombres"));
                        estudianteNodo.setApellidos(jsonArray.getString("apellidos"));
                        estudianteNodo.setArquitectura(jsonArray.getDouble("arquitectura"));
                        estudianteNodo.setProgramacion(jsonArray.getDouble("programacion"));
                        estudianteNodo.setEtica(jsonArray.getDouble("etica"));
                        estudianteNodo.setEstadistica(jsonArray.getDouble("estadistica"));
                        estudianteNodo.setContabilidad(jsonArray.getString("contabilidad"));
                        listaestudiantes.add(estudianteNodo);
                        Log.e("++++++++++++++++", "alumnos:" + listaestudiantes.size());
                    //}




                    //Log.e("++++++++++++++++", "alumnos:" + respuestaJson.getString("estado"));
                    //String resultJson = respuestaJson.getString("estado");
                   // if(resultJson.equals("1")){
                       // JSONObject estudianteJson = respuestaJson.getJSONObject("alumno");
                        //Estudiante estudianteNodo = new Estudiante();
                        //estudianteNodo.setCedula(Integer.parseInt(estudianteJson.getString("cedula")));
                        //estudianteNodo.setNombres(estudianteJson.getString("nombres"));
                        //estudianteNodo.setApellidos(estudianteJson.getString("apellidos"));
                        //estudianteNodo.setArquitectura(estudianteJson.getDouble("arquitectura"));
                        //estudianteNodo.setProgramacion(estudianteJson.getDouble("programacion"));
                        //estudianteNodo.setEtica(estudianteJson.getDouble("etica"));
                        //estudianteNodo.setEstadistica(estudianteJson.getDouble("estadistica"));
                        //estudianteNodo.setContabilidad(estudianteJson.getString("contabilidad"));

                    //listaestudiantes.add(estudianteNodo);

                      alumnoAdapter = new AdapterAlumno(globalContext, (ArrayList<Estudiante>) listaestudiantes);
                      listaBUscada.setAdapter(alumnoAdapter);
                      alumnoAdapter.notifyDataSetChanged();
                    //}
                    id.setText("");

                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

        });

        return vista;
         }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }




    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
