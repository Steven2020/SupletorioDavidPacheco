/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unl.proyecto.rest;

import com.unl.proyecto.datos.CrudService;
import com.unl.proyecto.modelo.Estudiante;
import java.util.List;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

/**
 *
 * @author david
 */

@Path("estudiante")
public class EstudianteRest {
    
    @Path("/guardar")
    @POST
    @Consumes({"application/json"})
    @Produces({"application/json"})
    public Response crearCliente(Estudiante est) {
        //mensaje http
        try {
            new CrudService().create(est);
            JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
            jsonObjectBuilder.add("estado", "creado");
            jsonObjectBuilder.add("cliente", "" + est);
            JsonObject jsonObject = jsonObjectBuilder.build();
            return Response.ok(jsonObject.toString()).build();
        } catch (Exception e) {
        }
        JsonObjectBuilder jsonObjectBuilder = Json.createObjectBuilder();
        jsonObjectBuilder.add("estado", "no creado");
        jsonObjectBuilder.add("error", "" + est);
        JsonObject jsonObject = jsonObjectBuilder.build();
        return Response.ok(jsonObject.toString()).build();
    }
    
    @Path("/todos")
    @GET
    @Produces({"application/json"})
    public List<Estudiante> getAllClientes() {
        List<Estudiante> lista = new CrudService().findWithQuery("select a from Estudiante a");
        return lista;
    }
    
    @Path("/estudianteId")
    @GET
    @Consumes({"application/json"})
    @Produces({"application/json"})
    public Response getCuentaId(@QueryParam("cedula") Integer id){
        CrudService cs = new CrudService();
        return Response.ok(cs.find(Estudiante.class, id)).build();
    }
    
}
