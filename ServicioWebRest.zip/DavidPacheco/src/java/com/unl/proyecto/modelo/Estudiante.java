/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unl.proyecto.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author david
 */
@Entity
@Table(name = "Estudiante")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Estudiante.findAll", query = "SELECT e FROM Estudiante e"),
    @NamedQuery(name = "Estudiante.findByCedula", query = "SELECT e FROM Estudiante e WHERE e.cedula = :cedula"),
    @NamedQuery(name = "Estudiante.findByNombres", query = "SELECT e FROM Estudiante e WHERE e.nombres = :nombres"),
    @NamedQuery(name = "Estudiante.findByApellidos", query = "SELECT e FROM Estudiante e WHERE e.apellidos = :apellidos"),
    @NamedQuery(name = "Estudiante.findByArquitectura", query = "SELECT e FROM Estudiante e WHERE e.arquitectura = :arquitectura"),
    @NamedQuery(name = "Estudiante.findByProgramacion", query = "SELECT e FROM Estudiante e WHERE e.programacion = :programacion"),
    @NamedQuery(name = "Estudiante.findByEtica", query = "SELECT e FROM Estudiante e WHERE e.etica = :etica"),
    @NamedQuery(name = "Estudiante.findByEstadistica", query = "SELECT e FROM Estudiante e WHERE e.estadistica = :estadistica"),
    @NamedQuery(name = "Estudiante.findByContabilidad", query = "SELECT e FROM Estudiante e WHERE e.contabilidad = :contabilidad")})
public class Estudiante implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "cedula")
    private Integer cedula;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "nombres")
    private String nombres;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "apellidos")
    private String apellidos;
    @Basic(optional = false)
    @NotNull
    @Column(name = "arquitectura")
    private double arquitectura;
    @Basic(optional = false)
    @NotNull
    @Column(name = "programacion")
    private double programacion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "etica")
    private double etica;
    @Basic(optional = false)
    @NotNull
    @Column(name = "estadistica")
    private double estadistica;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "contabilidad")
    private String contabilidad;

    public Estudiante() {
    }

    public Estudiante(Integer cedula) {
        this.cedula = cedula;
    }

    public Estudiante(Integer cedula, String nombres, String apellidos, double arquitectura, double programacion, double etica, double estadistica, String contabilidad) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.arquitectura = arquitectura;
        this.programacion = programacion;
        this.etica = etica;
        this.estadistica = estadistica;
        this.contabilidad = contabilidad;
    }

    public Integer getCedula() {
        return cedula;
    }

    public void setCedula(Integer cedula) {
        this.cedula = cedula;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public double getArquitectura() {
        return arquitectura;
    }

    public void setArquitectura(double arquitectura) {
        this.arquitectura = arquitectura;
    }

    public double getProgramacion() {
        return programacion;
    }

    public void setProgramacion(double programacion) {
        this.programacion = programacion;
    }

    public double getEtica() {
        return etica;
    }

    public void setEtica(double etica) {
        this.etica = etica;
    }

    public double getEstadistica() {
        return estadistica;
    }

    public void setEstadistica(double estadistica) {
        this.estadistica = estadistica;
    }

    public String getContabilidad() {
        return contabilidad;
    }

    public void setContabilidad(String contabilidad) {
        this.contabilidad = contabilidad;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cedula != null ? cedula.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Estudiante)) {
            return false;
        }
        Estudiante other = (Estudiante) object;
        if ((this.cedula == null && other.cedula != null) || (this.cedula != null && !this.cedula.equals(other.cedula))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.unl.proyecto.modelo.Estudiante[ cedula=" + cedula + " ]";
    }
    
}
